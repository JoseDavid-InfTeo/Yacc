#define PI 3.1416
#define NUMERO 15
#define SALUDO "Hola"

int main(){
	int caca = 8;
	int a = 8 + 8 + 9 + caca;
	float b;
	char c;
}
