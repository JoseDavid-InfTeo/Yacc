#define PI 3.1416
#define NUMERO 15
#define SALUDO "Hola"

float c,d = 5.3 + 2.4;
int a,b;

int main(){
    int g;
    h = a;
    g = a+5;
    z = 5 && f;
    printf("a a df",a,b,a+b);
    scanf("%d",&a);
    if(a==4){
    	a++;
    }

    if(b<9){
    	b=5;
    }else if (b>9){
    	b = a-5;
    }

    if(b<9){
    	b=5;
    }else {
    	b = a-5;
    }

    for (a=1;a>6;a++){
    	printf("y eso");
    }

	for (;a>6;){
    	printf("y eso");
    }

    while(1){
    	a++;
    }

    //Practica realizada por
    //David Heras Pino
    //Jose L Pariente Martinez
    //Copyright 2016 ©




}
